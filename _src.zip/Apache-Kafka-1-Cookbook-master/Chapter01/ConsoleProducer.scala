)]}'
{
  "id": "a680b6221c98e74cae3a877006eca6fabf7a88f2",
  "repo": "kafka",
  "revision": "0.8.2",
  "path": "core/src/main/scala/kafka/tools/ConsoleProducer.scala"
}
